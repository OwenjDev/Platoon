# Platoon: two-player browser card game

An unofficial, original-looking fan adaptation of **Platoon** from *Ni no Kuni: Wrath of the White Witch*.

## Try it quickly

1. Upload `index.html` to any static website host, such as GitHub Pages.
2. Open the website on your own computer and click **Create room**.
3. Copy the invitation link and open it on another computer (or a second tab for testing).
4. In the other browser, click **Join room**.
5. Arrange your cards, lock in your five platoons, and take turns choosing battles.

**No Firebase account, database, or backend code is required.** The application connects players directly using WebRTC and PeerJS's public signaling infrastructure. Both computers must have internet access and allow peer-to-peer connections. Some restricted networks may block connections, and public signaling has no uptime guarantee. If this becomes a problem, move to a dedicated signaling server or managed realtime backend.

## Publish to GitHub Pages

1. Create a new public repository in GitHub, such as `platoon`.
2. Add the `index.html` file to the root of the repository (you may also add this README).
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, and save.
5. After Pages publishes, visit `https://YOUR-USERNAME.github.io/platoon/`.
6. Click **Create room** and share the invite link with your friend.

## Game rules implemented

- One shuffled 54-card deck (52 standard cards and two Jokers), dealt 10 cards to each player.
- All 10 cards are assigned across exactly five nonempty platoons. A Wizard cannot be alone.
- King: beats non-special piles, loses to Bishop; King vs King compares totals.
- Bishop (Ace): loses to normal piles, defeats King; Bishop vs Bishop compares totals.
- Wizard (Joker): swaps ownership of the matched piles, reversing the winner; two Wizards cancel.
- The attacker selects one unused own platoon and one unused opponent platoon; attacker alternates each battle.
- First to three wins takes the match. If five battles finish without a player reaching three wins, compare wins or declare a draw.
- Rematches track match victories.

## Differences from the original casino game

This head-to-head version intentionally omits chip betting, prebattle predictions and the dealer's asymmetric tie rule. Cards are simple HTML-rendered playing cards, not copyrighted game artwork. Random first player is chosen automatically.

## Privacy and limitations

- The host browser shuffles and retains both players' full cards to enforce game rules. Guest cards are *not* displayed in the host UI, but a technically knowledgeable host can inspect them using developer tools. This is suitable for casual play with a friend, **not competitive or anti-cheat play**.
- Invite codes are easy to share and not secure authentication. Don't post them publicly.
- If the host closes the tab, the match ends. Games do not persist across refreshes.
- Networking works best over HTTPS (including GitHub Pages), on non-restrictive networks.
- For stronger secrecy and persistence, use Firebase with server-side rule checks or a dedicated multiplayer server.

## Troubleshooting

- If your friend cannot join, verify the exact six-character code, reload both tabs, and create a new room.
- If the multiplayer library cannot load, make sure the browser can reach `unpkg.com` and the PeerJS public signaling service.
- If connections fail on a school/work network, try a different connection or hotspot.
